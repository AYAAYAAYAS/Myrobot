#include <rtthread.h>
#include <rtdevice.h>

#include <board.h>
#include "aht10.h"
#include <drv_lcd.h>
#include <rttlogo.h>

#define DBG_TAG "main"
#define DBG_LVL         DBG_LOG
#include <rtdbg.h>
#define UART_NAME       "uart3"
#define UART_NAME_1       "uart2"
#define PWM_DEV_NAME        "pwm1"
#define PWM_DEV_CHANNEL     4
#define ADC_DEV_NAME        "adc1"
#define ADC_DEV_CHANNEL     5
#define REFER_VOLTAGE       330
#define CONVERT_BITS        (1 << 12)

#define PWM_DEV_CHANNEL     4
#define PIN_LED_B   GET_PIN(F,11)
#define PIN_LED_R   GET_PIN(F,12)

#define PIN_BEEP   GET_PIN(E,12)
#define PIN_LED_M  GET_PIN(E,13)

#define PIN_LED_1   GET_PIN(G,5)
#define PIN_LED_2   GET_PIN(G,4)
#define PIN_LED_3   GET_PIN(G,3)
//灯亮模拟开锁
#define PIN_LOCK_OPEN   GET_PIN(E,11)
#define PIN_LOCK_CLOSE   GET_PIN(E,15)
//步进电机
#define PIN_A   GET_PIN(F,4)
#define PIN_B   GET_PIN(F,5)
#define PIN_C   GET_PIN(F,6)
#define PIN_D   GET_PIN(F,7)
#define IN1(x)  do{x?rt_pin_write(PIN_A,1):rt_pin_write(PIN_A,0);}while(0);
#define IN2(x)  do{x?rt_pin_write(PIN_B,1):rt_pin_write(PIN_B,0);}while(0);
#define IN3(x)  do{x?rt_pin_write(PIN_C,1):rt_pin_write(PIN_C,0);}while(0);
#define IN4(x)  do{x?rt_pin_write(PIN_D,1):rt_pin_write(PIN_D,0);}while(0);

typedef enum
{
    CW=0X00,
    CCW=0X01
}step_dir;

//按键
#define PIN_KEY_UP      GET_PIN(C,5)
#define PIN_KEY_DOWN    GET_PIN(C,1)
#define PIN_KEY_LEFT   GET_PIN(C,0)
#define PIN_KEY_RIGHT   GET_PIN(C,4)
#define count   7

static  rt_thread_t thread1=NULL;
static  rt_thread_t thread3=NULL;
static  rt_thread_t thread4=NULL;
static  rt_thread_t thread5=NULL;

struct rt_device_pwm *pwm_dev;
static rt_device_t serial;
static rt_device_t serial_1;
static rt_device_t adc_dev;

rt_uint32_t     period=2500000,
                pulse=0,
                dir=1;
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;


static rt_mutex_t dynamic_mutex = NULL;
static rt_mutex_t mutex;

static struct rt_semaphore rx_sem;
static struct rt_semaphore rx_sem_1;
static struct rt_semaphore SEVOR_sem;
static struct rt_semaphore LED_sem;

char cmd=0;
char pdcmd=0;

int buffer_1,buffer_2;

int flag_a=0;
char password_flag='a';
char p_flag;
int key_flag=0;
int flag;

float humidity,temperature;
rt_uint32_t value, vol;
int PASSWORD[4];
int INIT_PASSWORD[4]={1,2,3,4};

typedef struct
{
        int X1;
        int X2;
        int X3;
        int X4;
        int X5;
        int X6;
        int X7;
        int X8;
        int head;
        int head2;
        int end;
        int COMMAND;
}PW;
PW MM;
void Servo_SetAngle();
void receive(int16_t Com_Data);

//线程部分
static void aht10_thread();
static void serial_thread();
static void serial_thread_2();
static void Servo_thread();
static void LED_thread();
static void menu_thread();

//步进电机驱动
void bj_control(uint8_t step);
void motor_run(uint8_t dir,uint8_t rpm);
void NULL_thread();
void motor_STOP();
void motor_angle(int angle);

//密码获取部分
void task_key_1();
int Key_read();
void key_thread();
void password_entry();
void get_password(int32_t Com_Data);
void password_clean();

static rt_err_t uart_input(rt_device_t dev,rt_size_t size){
    rt_sem_release(&rx_sem);
    return RT_EOK;
}

static rt_err_t uart_input_1(rt_device_t dev,rt_size_t size){
    rt_sem_release(&rx_sem_1);
    return RT_EOK;
}

rt_err_t ret=RT_EOK;

int main(int argc, char *argv[])
{
    serial = rt_device_find(UART_NAME);
    config.baud_rate = BAUD_RATE_115200;
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    serial_1 = rt_device_find(UART_NAME_1);
    config.baud_rate = BAUD_RATE_115200;
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&SEVOR_sem, "SEVOR_sem",0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&LED_sem, "LED_sem", 0, RT_IPC_FLAG_FIFO);
    rt_sem_init(&rx_sem_1, "rx_sem_1", 0, RT_IPC_FLAG_FIFO);


    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(serial, uart_input);

    rt_device_control(serial_1, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_open(serial_1, RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(serial_1, uart_input_1);

    lcd_clear(WHITE);
    lcd_set_color(WHITE, BLACK);

    rt_pin_mode(PIN_LED_R,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LED_B,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LED_M,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_BEEP ,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LED_1,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LED_3,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LED_2,PIN_MODE_OUTPUT);

    rt_pin_mode(PIN_A,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_B,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_C,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_D,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LOCK_OPEN,PIN_MODE_OUTPUT);
    rt_pin_mode(PIN_LOCK_CLOSE,PIN_MODE_OUTPUT);

    rt_pin_mode(PIN_KEY_UP,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(PIN_KEY_DOWN,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(PIN_KEY_LEFT,PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(PIN_KEY_RIGHT,PIN_MODE_INPUT_PULLUP);

    dynamic_mutex = rt_mutex_create("dmutex", RT_IPC_FLAG_PRIO);
    mutex = rt_mutex_create("mutex", RT_IPC_FLAG_FIFO);

    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
//    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
    rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL);
//    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
//    Servo_SetAngle();


    adc_dev = (rt_adc_device_t)rt_device_find(ADC_DEV_NAME);
    ret = rt_adc_enable(adc_dev, ADC_DEV_CHANNEL);
    rt_pin_write(PIN_LOCK_CLOSE, PIN_LOW);
    rt_pin_write(PIN_LOCK_OPEN, PIN_LOW);

   thread1 = rt_thread_create(
              "thread1",
              aht10_thread,
                NULL,
                1024,
                20,
                 20);

 rt_thread_t  thread2 = rt_thread_create(
              "thread2",
              serial_thread,
                NULL,
                1024,
                19,
                 10);

      thread3 = rt_thread_create(
                   "thread3",
                   menu_thread,
                     NULL,
                     1024,
                    23,
                      5);
      thread4 = rt_thread_create(
                         "thread4",
                         serial_thread_2,
                           NULL,
                           1024,
                          19,
                            10);
      thread5 =rt_thread_create(
              "thread5",
              NULL_thread,
                NULL,
                512,
                22 ,
                 10);
           rt_thread_startup(thread1);
          rt_thread_startup(thread2);
           rt_thread_startup(thread3);
           rt_thread_startup(thread4);
//           rt_thread_startup( thread5);

}

void serial_thread()
{

   while(1)
   {
       while(rt_device_read(serial, -1,&cmd,128)!=1)
       {
           //@
           rt_sem_take(&rx_sem,RT_WAITING_FOREVER);
       }
       if(key_flag==1)
       {
           if(p_flag==0)
           {
               rt_device_write(serial, 0,97, 1);
               p_flag++;

           }
//           if( p_flag>1)
//           {
//               p_flag=0;
//           }
           get_password(cmd);
       }

   }
}

void serial_thread_2()
{

   while(1)
   {
       while(rt_device_read(serial_1, -1,&pdcmd,1)!=1)
       {

           rt_sem_take(&rx_sem_1,RT_WAITING_FOREVER);
       }
   }
}

void aht10_thread()
{

    const char *i2c_bus_name = "i2c3";
    aht10_device_t dev;
    dev=aht10_init(i2c_bus_name);
    rt_thread_mdelay(2000);
    lcd_show_string(10,69 + 16, 16, "CMD:");
    lcd_show_string(10,69 + 16 + 24 + 32 , 16, "humidity:");
    lcd_show_string(10,69 + 16 + 24  ,16, "temperature:");
    lcd_show_string(69+ 16+16 ,69 + 16 + 24 + 32,16,".");
    lcd_show_string(69+ 16 +24+16,69 + 16 + 24,16,".");
    lcd_show_string(8,69 + 16 + 24 + 16,16,".");

    while (1)
        {

            rt_mutex_take(dynamic_mutex,RT_WAITING_FOREVER);
            humidity= aht10_read_humidity(dev)-30;
            temperature=aht10_read_temperature(dev);
            value = rt_adc_read(adc_dev, ADC_DEV_CHANNEL);
            vol = value * REFER_VOLTAGE / CONVERT_BITS ;
            if(temperature<30)
            {
                rt_pin_write(PIN_BEEP, PIN_HIGH);
             }
            else
            {
                rt_pin_write(PIN_BEEP, PIN_LOW);
            }
            if(vol>189 && key_flag==1)
            {
                rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,7*100000);
          }
            lcd_show_num(0 ,16+24 ,MM.head,8,16);
            lcd_show_num(16+12 ,16+24 ,MM.head2,8,16);
            lcd_show_num(32+12+8 ,16+24 ,PASSWORD[0],8,16);
            lcd_show_num(48+12+16 ,16+24 ,PASSWORD[1],8,16);
            lcd_show_num(64+12+32 ,16+24 ,PASSWORD[2],8,16);
            lcd_show_num(80+12+40 ,16+24 ,PASSWORD[3],8,16);
            lcd_show_num(80+12+40+16 ,16+24 ,MM.end,8,16);

            lcd_show_num(16 ,0 ,key_flag,8,16);
            lcd_show_num(16 ,16 ,p_flag,8,16);
            lcd_show_num(69+16 ,69 + 16 ,cmd,8,16);
            lcd_show_num(69+16+32 ,69 + 16 ,pdcmd,8,16);

            lcd_show_num(69+ 16 ,69 + 16 + 24 + 32,humidity,8,16);
            lcd_show_num(69+ 16 +24,69 + 16 + 24,temperature,8,16);
            lcd_show_num(69+ 16+24 ,69 + 16 + 24 + 32,(int)(humidity * 10) % 10,8,16);
            lcd_show_num(69+ 16 +24+24,69 + 16 + 24,(int)(temperature * 10) % 10,8,16);
            lcd_show_num(0,69 + 16 + 24 + 16,(int)(vol / 100),8,16);
            lcd_show_num(16,69 + 16 + 24 + 16,(int)(vol % 100),8,16);
            rt_thread_mdelay(1000);
            rt_mutex_release(dynamic_mutex);

        }
}
void menu_thread()
{

    while(1)
    {
        if(key_flag==0)
        {
            key_thread();
        }
        if(key_flag==1)
        {
            task_key_1();

        }
        if(key_flag==2 )
        {
            while(1)
            {
//                pulse=24*100000;
//                rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,24*100000);

                if(cmd==48)//0
                {
                      rt_pin_write(PIN_LED_M, PIN_LOW);
                 }
                else if(cmd==49)//1
               {
                    rt_pin_write(PIN_LED_M, PIN_HIGH);
                     LED_thread();
                }
                else if(cmd==50)//2
                {
                    rt_pin_write(PIN_LED_M, PIN_HIGH);
                    Servo_thread();
                }
                else if(cmd==51)//3
                {
                    rt_pin_write(PIN_LED_M, PIN_HIGH);
                    NULL_thread();
                }
                //
                if(pdcmd==241)
                {
                    rt_pin_write(PIN_LED_1, PIN_HIGH);       //厨房灯打开

                }
                else if(pdcmd==242)
                {
                    rt_pin_write(PIN_LED_1, PIN_LOW);       //厨房灯关闭
                }
                if(pdcmd==243)
                {
                    rt_pin_write(PIN_LED_2, PIN_HIGH);      //卧室灯打开
                }
                else if(pdcmd==246)
                {
                    rt_pin_write(PIN_LED_2, PIN_LOW);       //卧室灯关闭
                }
                if(pdcmd==237)
                {
                    rt_pin_write(PIN_LED_3, PIN_HIGH);      //客厅灯打开
                }
                else if(pdcmd==238)
                {
                    rt_pin_write(PIN_LED_3, PIN_LOW);       //客厅灯关闭
                }
                if(pdcmd==249)
                {
                    rt_pin_write(PIN_LED_1, PIN_HIGH);
                    rt_pin_write(PIN_LED_2, PIN_HIGH);
                    rt_pin_write(PIN_LED_3, PIN_HIGH);      //所有灯打开
                }
                else if(pdcmd==250)
                {
                    rt_pin_write(PIN_LED_1, PIN_LOW);
                    rt_pin_write(PIN_LED_2, PIN_LOW);
                    rt_pin_write(PIN_LED_3, PIN_LOW);       //所有灯关闭
                }
                if(pdcmd==251)//打开舵机
                {


                    if(vol>189)
                   {
                        rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,7*100000);
                    }
                    else {
                        rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,24*100000);
                    }
                }
                if(pdcmd==252)//关闭舵机
                {
                    rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,7*100000);
                }
                if(pdcmd==253)//收起窗帘
                {
                    motor_run(CW,12);
                }
                if(pdcmd==254)//放下窗帘
                {
                    motor_run(CCW,12);
                }
                if(pdcmd==255)//放下窗帘
                {
                    motor_STOP();
                }

            }
        }
    }
}
void Servo_thread()
{
    while(1)
    {
        rt_pin_write(PIN_LED_R, PIN_HIGH);
        if(cmd==53)
        {
           rt_thread_mdelay(50);

           pulse=24*100000;
           rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,pulse);
           cmd=5;

        }
        if(cmd==52)
        {
              rt_thread_mdelay(50);
              pulse=15*100000;
              rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,pulse);
              cmd=5;
        }
        if(cmd==51)
        {
              rt_thread_mdelay(50);
              pulse=7*100000;
              rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,pulse);
              cmd=5;
        }
        if(cmd==48)
        {
            break;
        }

    }
    return;

}
void Servo_SetAngle()
{

    rt_pwm_set(pwm_dev,PWM_DEV_CHANNEL,period,7*100000);
}
void LED_thread()
{

    int flag_1=1,flag_2=1,flag_3=1;
    while(1)
    {
        rt_pin_write(PIN_LED_B, PIN_HIGH);
        if(cmd==51)
        {
           rt_pin_write(PIN_LED_1,flag_1);
           flag_1++;
           if(flag_1>1)
           {
               flag_1=0;
           }
           cmd=5;
        }
        if(cmd==50)
        {
            rt_pin_write(PIN_LED_2,flag_2);
            flag_2++;
          if(flag_2>1)
          {
              flag_2=0;
           }
          cmd=5;
        }
        if(cmd==52)
        {
            rt_pin_write(PIN_LED_3,flag_3);
            flag_3++;
            if(flag_3>1)
            {
                flag_3=0;
           }
            cmd=5;
        }
        if(cmd==48)
        {
           break;
        }
    }
    return;
}
void NULL_thread()
{
    while(1)
    {
        if(cmd==56)
        {
            motor_run(CCW,15);

        }
        if(cmd==57)
        {
            motor_run(CW,15);
        }
        if(cmd==48)
        {
            motor_STOP();
            break;
        }
    }
    return;

}
void bj_control(uint8_t step)
{
    switch(step)
    {
        case 0://A
            IN1(1);
            IN2(0);
            IN3(0);
            IN4(0);
            break;
        case 1://AB
            IN1(1);
            IN2(1);
            IN3(0);
            IN4(0);
            break;
        case 2://B
            IN1(0);
            IN2(1);
            IN3(0);
            IN4(0);
            break;
        case 3://BC
            IN1(0);
            IN2(1);
            IN3(1);
            IN4(0);
            break;
        case 4://C
            IN1(0);
            IN2(0);
            IN3(1);
            IN4(0);
            break;
        case 5://CD
            IN1(0);
            IN2(0);
            IN3(1);
            IN4(1);
            break;
        case 6://D
            IN1(0);
            IN2(0);
            IN3(1);
            IN4(1);
            break;
        case 7://DA
            IN1(1);
            IN2(0);
            IN3(0);
            IN4(1);
            break;
        default:
            break;
    }
}
//time 1min=60s=60*1000ms=60*1000*1000us
//angle 360° / (5.625°/64 )= 4096
//1-17 RPM
void motor_run(uint8_t dir,uint8_t rpm)

{
    if(dir==CCW)
    {
            for(uint8_t i=8;i>0;i--)
            {
                if(rpm>17)rpm=17;
                 bj_control(i);
                 rt_hw_us_delay(60000000/4096/rpm);
            }

    }
    if(dir==CW)
     {
        for(uint8_t i=0;i<8;i++)
        {
                if(rpm>17)rpm=17;
                 bj_control(i);
                 rt_hw_us_delay(60000000/4096/rpm);

        }
      }

}
void motor_STOP()
{
         IN1(0);
         IN2(0);
         IN3(0);
         IN4(0);

}

void motor_angle(int angle)
{
    if(angle>0)
    {
        for(uint8_t j=0;j<(64 * 64*angle);j++)
        {
            motor_run(CCW,17);
        }
        motor_STOP();
    }
    if(angle<0)
    {
        for(uint8_t j=0;j<(64 * 64*(-angle));j++)
        {
               motor_run(CW,17);
       }
        motor_STOP();
    }

}

int Key_read()
{
    uint8_t KeyNum = 0;
    if(rt_pin_read(PIN_KEY_UP)==PIN_LOW)
    {
        rt_thread_mdelay(20);
        if(rt_pin_read(PIN_KEY_UP)==PIN_LOW)
        {
            rt_thread_mdelay(10);
            KeyNum = 1;
        }
    }
    if(rt_pin_read(PIN_KEY_DOWN)==PIN_LOW)
    {
         rt_thread_mdelay(20);
         if(rt_pin_read(PIN_KEY_DOWN)==PIN_LOW)
         {
             rt_thread_mdelay(10);
             KeyNum = 2;
         }
    }
    if(rt_pin_read(PIN_KEY_LEFT)==PIN_LOW)
    {
         rt_thread_mdelay(20);
         if(rt_pin_read(PIN_KEY_LEFT)==PIN_LOW)
         {
             rt_thread_mdelay(10);
             KeyNum = 3;
         }
    }
    if(rt_pin_read(PIN_KEY_RIGHT)==PIN_LOW)
    {
         rt_thread_mdelay(60);
         if(rt_pin_read(PIN_KEY_RIGHT)==PIN_LOW)
         {
             rt_thread_mdelay(10);
             KeyNum = 4;
         }
    }
    return KeyNum;
}

void key_thread()
{
    uint8_t menu_scan=1;
    uint8_t menu_flag;
    while(1)
    {
        menu_flag=Key_read();
        if(menu_flag==1)
        {
            key_flag=1;
            break;
        }
        if(menu_flag==2)
        {
            p_flag=0;
        }
        if(menu_flag==3)
        {
             key_flag=2;
             break;
        }
    }
    return;
}


 void task_key_1()
 {
         int is_correct = 1;
         password_entry();
        for (int i = 0; i < 4; i++)
        {
            if (PASSWORD[i] != INIT_PASSWORD[i])
                is_correct=0;
                break;
        }
        if (is_correct)
        {
            key_flag = 2;
            rt_device_write(serial_1, 0,0xff, 1);//密码正确
            rt_pin_write(PIN_LOCK_OPEN, PIN_HIGH);
            rt_pin_write(PIN_LOCK_CLOSE, PIN_LOW);
        }
        else
        {
//            key_flag = 0;
            rt_device_write(serial_1, 0,0xfe, 1);//密码错误
            rt_pin_write(PIN_LOCK_CLOSE, PIN_HIGH);
            rt_pin_write(PIN_LOCK_OPEN, PIN_LOW);
        }
}

void get_password(int32_t Com_Data)
{
    static int RxState = 0;
    static int RxCount = 0;
    static uint8_t RxBuffer[count] = {0};

    switch (RxState)
    {
        case 0:
            if (Com_Data == 0x2c)
            {
                RxState = 1;
                RxBuffer[RxCount++] = Com_Data;
                MM.head = Com_Data;
            }
            break;
        case 1:
            if (Com_Data == 0x2a)
            {
                RxState = 2;
                RxBuffer[RxCount++] = Com_Data;
                MM.head2 = Com_Data;
            }
            else
            {
                RxState = 0;
                RxCount = 0;
            }
            break;
        case 2:
            RxBuffer[RxCount++] = Com_Data;
            if (RxCount >= count || Com_Data == 0x5B)
            {
                RxState = 3;
                MM.X1 = RxBuffer[2];
                PASSWORD[0] = MM.X1;
                MM.X2 = RxBuffer[3];
                PASSWORD[1] = MM.X2;
                MM.X3 = RxBuffer[4];
                PASSWORD[2] = MM.X3;
                MM.X4 = RxBuffer[5];
                PASSWORD[3] = MM.X4;
                MM.end = RxBuffer[6];
                RxCount = 0;
                RxState = 0;
                password_flag = 1;

            }
            break;
        case 3:
            if (Com_Data == 0x5B)
            {
                RxState = 0;
                RxCount = 0;
            }
            else
            {
                RxState = 0;
                RxCount = 0;
            }
            break;
        default:
            RxState = 0;
            RxCount = 0;
            break;
    }
}
void password_entry()
{
    PASSWORD[0]=MM.X1;
    PASSWORD[1]=MM.X2;
    PASSWORD[2]=MM.X3;
    PASSWORD[3]=MM.X4;
}
void password_clean()
{
    PASSWORD[0]=0;
    PASSWORD[1]=0;
    PASSWORD[2]=0;
    PASSWORD[3]=0;
}

