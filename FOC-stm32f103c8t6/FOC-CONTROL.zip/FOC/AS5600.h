#ifndef _AS5600_H
#define _AS5600_H


unsigned short getRawCount();
void AS5600_Init(void);
float getAngle_Without_track();
float getAngle(void);


#endif