#ifndef _TRACE_GRAY_H
#define _TRACE_GRAY_H

#include "gpio.h"

void trace_red_2(void);

#endif
