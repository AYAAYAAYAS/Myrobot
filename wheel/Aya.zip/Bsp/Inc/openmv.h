#ifndef __OPENMV_H
#define __OPENMV_H
#include "stm32f1xx.h"
#include <stdio.h>
#define count 13


void openmv_receive(int16_t Com_Data);
void data_deal(uint8_t *data);
#endif
