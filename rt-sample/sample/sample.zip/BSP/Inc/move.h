//
// Created by Administrator on 2024/5/10.
//

#ifndef CONTROL_MOVE_H
#define CONTROL_MOVE_H

void left_wheel(int in1,int in2);
void right_wheel(int in3,int in4);
void forward();
void turnleft();
void turnright();
void stop();

#endif //CONTROL_MOVE_H
