#ifndef __APPLY_H
#define __APPLY_H


typedef struct{


}MENU;

void APP_init();
void APPLY();

#endif