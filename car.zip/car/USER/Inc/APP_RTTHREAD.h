#ifndef _APP_RT_THREAD_H_
#define _APP_RT_THREAD_H_

void MX_RT_Thread_Init(void);

#endif
