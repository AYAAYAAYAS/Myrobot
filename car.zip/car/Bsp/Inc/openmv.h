#ifndef __OPENMV_H
#define __OPENMV_H

#include "main.h"
#define count 4


void openmv_receive(int16_t Com_Data);
void data_deal(uint8_t *data);

#endif
